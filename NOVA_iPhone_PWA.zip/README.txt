NOVA — prototype iPhone
1. Héberger ces fichiers sur un service web HTTPS.
2. Ouvrir l'adresse dans Safari sur l'iPhone.
3. Safari > Partager > Sur l'écran d'accueil.
4. Lancer NOVA depuis l'icône.

Ce package constitue l'interface PWA de base. Les fonctions IA, voix, mémoire et automatisations nécessitent ensuite des services/backend et des autorisations explicites.
